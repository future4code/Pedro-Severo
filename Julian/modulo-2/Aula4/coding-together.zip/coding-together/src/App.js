import React from 'react';
import DoisBotoes from './components/Exercicio1e2/DoisBotoes';
import ListaNoEstado from "./components/Exercicio4/ListaNoEstado";
import ListasNoComponenteFuncional from './components/Exercicio3/ListasNoComponenteFuncional';

const App = () => {
  return (
    <div>
      {/* <DoisBotoes /> */}
      {/* <ListasNoComponenteFuncional /> */}
      {/* <ListaNoEstado /> */}
    </div>
  )
}

export default App;